This is a new automated arena for Smaug 1.4.
This snippet is based on the ROM arena snippet by Kevin Hoogheem
I also added a one on one challenge part to the code so
players can dual each other without having a bunch of people 
in the way. This code was ported to SMAUG1.4 by LrdElder.
If you have any cool additions or questions just e-mail me at
tdison@swetland.net - LrdElder 10/22/98
You can do anything you want with this code.

INSTALLATION:
Add to mud.h
------------
in char_data ...
CHAR_DATA	  *challenged; 
CHAR_DATA *    	  betted_on;
int        	  bet_amt;

down at the bottom of mud.h with all the rest of this stuff ...
#define GET_BETTED_ON(ch)    ((ch)->betted_on)
#define GET_BET_AMT(ch) ((ch)->bet_amt)
#define IN_ARENA(ch)            (IS_SET((ch)->in_room->room_flags, ROOM_ARENA))

In with all the othe pulse definitions ....
#define PULSE_ARENA                             (30 * PULSE_PER_SECOND)

under * Command functions .....
DECLARE_DO_FUN( do_accept       );
DECLARE_DO_FUN( do_ahall        );
DECLARE_DO_FUN( do_arena        );
DECLARE_DO_FUN( do_awho         );
DECLARE_DO_FUN( do_bet          );
DECLARE_DO_FUN( do_challenge    );
DECLARE_DO_FUN( do_chaos        );
DECLARE_DO_FUN( do_decline      );

Add to update.c
---------------
At the top of the file ...
extern void start_arena();
extern void do_game();
extern int in_start_arena;
extern int ppl_in_arena;
extern int ppl_challenged;
extern int num_in_arena();
 
In the update_handler function at the top of the function ....
    static  int     pulse_start_arena = PULSE_ARENA;
    static  int     pulse_arena = PULSE_ARENA;

then later on in the function ....

    if(in_start_arena || ppl_challenged)
    if( --pulse_start_arena <= 0)
    {
      pulse_start_arena = PULSE_ARENA;
      start_arena();
    }

    if(ppl_in_arena)
    if(( --pulse_arena <= 0) || (num_in_arena()==1))
    {
      pulse_arena = PULSE_ARENA;
      do_game();
    }

In fight.c
-------------
There's some changes to be made here so that players can fight each other.
Normally a char with level 15 cannot fight a char of level 30, but if they
challenge them or join the chaos arena, they should be able to ... also a
non-pkill can join in the arena, and not recieve an attacker flag.

In the is_safe function change ...
if(IS_PACIFIST(ch)) /* Fireblade */
to ...
if((IS_PACIFIST(ch)) && !IN_ARENA(ch)) /* Fireblade */

and change ...
if ( get_age( ch ) < 18 || ch->level < 5 )
to ...
if ( (get_age( ch ) < 18 || ch->level < 5) && !IN_ARENA( ch ) )

and change ...
if ( get_age( victim ) < 18 || victim->level < 5 )
to ...
if ( (get_age( victim ) < 18 || victim->level < 5) && !IN_ARENA( victim ) )

and change ...
    if ( ch->level - victim->level > 5
    ||   victim->level - ch->level > 5 )
to ...
    if ( (ch->level - victim->level > 15
    ||   victim->level - ch->level > 15 ) && !IN_ARENA( ch ))

and change ...
    if ( get_timer(ch, TIMER_PKILLED) > 0 )
to ..
    if ( (get_timer(victim, TIMER_PKILLED) > 0) && !IN_ARENA(ch) )

and change ...
    if ( get_timer(ch, TIMER_PKILLED) > 0 )
to ...
    if ( (get_timer(ch, TIMER_PKILLED) > 0) && !IN_ARENA(ch) )

and later on in the file at the BOTTOM of the check_attacker funtion change ....
    if ( IS_NPC(ch)
    ||   ch == victim
    ||   ch->level >= LEVEL_IMMORTAL
    ||   xIS_SET(ch->act, PLR_ATTACKER)
    ||   xIS_SET(ch->act, PLR_KILLER) )
        return;
to ...
    if ( IS_NPC(ch)
    ||   ch == victim
    ||   ch->level >= LEVEL_IMMORTAL
    ||   xIS_SET(ch->act, PLR_ATTACKER)
    ||   xIS_SET(ch->act, PLR_KILLER)
    ||   IN_ARENA(ch) )
        return;



In act_comm.c
-------------
At the top of the file with all the other externals ....
void sportschan(char *);

In the do_quit function ....
At the top of the function add 
char qbuf[MAX_INPUT_LENGTH];

then somewhere in the middle add ...
    if ( ch->challenged )
    {
      sprintf(qbuf,"%s has quit! Challenge is void. WHAT A WUSS!",ch->name);
      ch->challenged=NULL;
      sportschan(qbuf);
    }


In handler.c
------------
In the extract_char function ......
    if (IS_SET(ch->in_room->room_flags, ROOM_ARENA))
    {
        ch->hit = ch->max_hit;
        ch->mana = ch->max_mana;
        ch->move = ch->max_move;
    }

In tables.c
-----------
You should be able to figure out where all this goes ....
In .... DO_FUN *skill_function( char *name )
Under case 'a': ....

        if ( !str_cmp( name, "do_accept" ))             return do_accept;
        if ( !str_cmp( name, "do_ahall" ))              return do_ahall;
        if ( !str_cmp( name, "do_arena" ))              return do_arena;
        if ( !str_cmp( name, "do_awho" ))               return do_awho;

Under case 'b': ...
        if ( !str_cmp( name, "do_bet" ))                return do_bet;

Under case 'c': ...
        if ( !str_cmp( name, "do_challenge" ))          return do_challenge; 
        if ( !str_cmp( name, "do_chaos" ))              return do_chaos;

Under case 'd': ...
        if ( !str_cmp( name, "do_decline" ))            return do_decline;

In .... char *skill_name( DO_FUN *skill )
    if ( skill == do_accept )           return "do_accept";
    if ( skill == do_ahall )            return "do_ahall";
    if ( skill == do_arena )            return "do_arena";
    if ( skill == do_awho )             return "do_awho";
    if ( skill == do_bet )              return "do_bet";
    if ( skill == do_challenge )        return "do_challenge";
    if ( skill == do_chaos )            return "do_chaos";
    if ( skill == do_decline )          return "do_decline";


Change around the Makefile to include the file newarea.c.
You also have to set the room flags in the limbo.are for the arena.
Remove the exits from the comabtants chambers (vnum 42 and 43)

To add the commands .... from within the mud shell ....
cedit accept create do_accept
cedit ahall create do_ahall
cedit arena create do_arena
cedit awho create do_awho
cedit bet create do_bet
cedit challenge create do_challenge
cedit chaos create do_chaos
cedit decline create do_decline
cedit save cmdtable

All the levels should be set pretty low except for the chaos command.
That should be about it for now .... If you have any problems, just e-mail
me.

