First I'd like to thank gary and his clan code, that is what i first started using as
the base.  It provided a great OLC, and great layout of code.  I'd like to thank Morpheous
of irc.acestar.org #ROM, for his help on linked lists, and also mapleman of ircprojects.net
with his help on the del and add of members to the linked list.  Seeing as I strongly believe
in giving credit,  my hats off to these 3.

To install:
Put order.c in your source
do all the additions from changes.txt
upload the order folder and it's contents to the root directory, (same place players & src folders are).
Make clean, and boot.

Current Features version 1.0:
* Full OLC Support
* Patron/Unpatron
* Ranks in the Order
* Link lists load/support
* followers command to show followers

Future Features:
* Donation to God (will result in god points)
* Rank powers (certain powers for followers of certain ranks, generic)
* Temple support/peace zone if in own temple
* Full REDIT supportt to make temples

I think that covers just about everything right now.  If you install this snippet, please 
do not take out the author and thanks names, alot of work has been done by all and you should
always give credit where credit is do.  And if you'd be so kind as to e-mail me
muerte@acestar.org, so I know it's being used and can see it in action for others.  Feel free
to also e-mail me ideas, changes, bugs that you may find or want added.

Thank you,
Charles Tillery
Ao/Muerte
mudsanddragons.com 4000
www.mudsanddragons.com