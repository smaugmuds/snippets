/***************************************************************************
*   MND is copyright 2000-2002 Charles Tillery (Muerte/Ao)                 *
*   By using this code, you have agreed to follow the terms of the         *
*   ROM license, in the file doc/mnd.license and all prior licenses        *
*   This header is not to be removed from ANY file                         *
*                                                                          *
*   mysql basics programmed by flugh (Jim Robinson) and Rheede (Bobby      *
*   Hicks)                                                                 *
*                                                                          *
*   Version 1.0                                                            *
***************************************************************************/

#include <mysql/mysql.h>

/* Global Declarations */
MYSQL			mysqlconn;
MYSQL_RES	*	result;
MYSQL_ROW		row;

/* declarations */
#define MY_SERVER "SERVER NAME/IP"
#define MY_USER   "USER NAME"
#define MY_PWD    "USER PASSWORD"
#define MY_DB     "DATABASE NAME"

/* prototypes */
bool open_db( void );
void close_db( void );


