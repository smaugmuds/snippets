/***************************************************************************
*   MND is copyright 2000-2002 Charles Tillery (Muerte/Ao)                 *
*   By using this code, you have agreed to follow the terms of the         *
*   ROM license, in the file doc/mnd.license and all prior licenses        *
*   This header is not to be removed from ANY file                         *
*									   *
*   mysql basics programmed by flugh (Jim Robinson) and Rheede (Bobby      *
*   Hicks) for the mysql help system.                                      *
*                                                                          *
*   Version 1.0                                                            *
***************************************************************************/

#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "merc.h"
#include "mysql.h"

bool open_db( void )
{
	if (!mysql_init(&mysqlconn))
	{
		logf("For some reason, open_db couldn't init a mysql connection. exitting (BEAUTIFYME)");
		return FALSE;
	}
	if ((mysql_real_connect(&mysqlconn, MY_SERVER, MY_USER, MY_PWD, MY_DB, 0, NULL, 0)) == NULL)
	{
		logf("open_db died connecting to the mysql server");
		mysql_close(&mysqlconn);
		return FALSE;
	}
	return TRUE;
}

void close_db( void )
{
	mysql_close(&mysqlconn);
	return;
}
