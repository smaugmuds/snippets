/******************************************************************************
 *     File: materia.c                                                        *
 * Contents: Authentic Materia system, ala FFVII.                             *
 *   Author: Cab Himself                                                      *
 *     Note: Be careful when installing snippets, always read through them    *
 *           and make sure you know how they work.                            *
 *  License: If you wish to use this code, this header must remain in tact.   *
 *           Also, while not required, credit within the MUD would be very    *
 *           appreciated.                                     -- Cab Himself  *
 ******************************************************************************/

#if defined(macintosh)
#include <types.h>
#include <time.h>
#else
#include <sys/types.h>
#include <sys/time.h>
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "merc.h"
#include "interp.h"

void show_list_to_char (OBJ_DATA * list, CHAR_DATA * ch, bool fShort,
                        bool fShowNothing);

int ap_per_level (int level)
{
	switch (level)
	{
		default:
			return 0;
		case 0:
			return 1000;
		case 1:
			return 2500;
		case 2:
			return 5000;
		case 3:
			return 10000;
		case 4:
			return 20000;
	
	}
	return 0;
}

void gain_ap (CHAR_DATA * ch, int ap)
{
	OBJ_DATA * list, * obj;

	printf_to_char (ch, "All of your active Materia gain %d AP!\n\r", ap);

	for (list = ch->carrying; list != NULL; list = list->next_content)
	{
		if ((list->item_type == ITEM_WEAPON || list->item_type == ITEM_ARMOR)
			&& list->wear_loc != WEAR_NONE)
		{
			for (obj = list->contains; obj != NULL; obj = obj->next_content)
			{
				if (ap_per_level (obj->level) > 0)
				{
					obj->ap += ap;

					while (obj->level < 6 && obj->ap >= ap_per_level (obj->level))
					{
						printf_to_char (ch, "{G%s has %s!{x\n\r",
										obj->short_descr,
										obj->level == 5 ? "been mastered" :
										"gained a level");

						if (ap_per_level (obj->level) > 0)
							obj->ap -= ap_per_level (obj->level);
						else
							obj->ap = 0;

						obj->level++;
					}
				}
			}
		}
	}
}

bool has_materia_slot (OBJ_DATA * obj, int slot)
{
	OBJ_DATA * materia;

	for (materia = obj->contains; materia != NULL; materia = materia->next_content)
	{
		if (materia->materia_slot == slot)
			return TRUE;
	}

	return FALSE;
}

bool is_linked_materia (OBJ_DATA * aMat, OBJ_DATA * bMat)
{
	OBJ_DATA * eq;
	int h_slot, l_slot, i;

	if ((eq = aMat->in_obj) == NULL)
		return FALSE;

	if (eq != bMat->in_obj)
		return FALSE;


	if (aMat->materia_slot > bMat->materia_slot)
	{
		h_slot = aMat->materia_slot;
		l_slot = bMat->materia_slot;
	}
	else
	{
		h_slot = bMat->materia_slot;
		l_slot = aMat->materia_slot;
	}

	for (i = l_slot; i < h_slot; i++)
	{
		if (i == 0 && eq->joints[0] == FALSE) return FALSE;
		if (i == 1 && eq->joints[1] == FALSE) return FALSE;
		if (i == 2 && eq->joints[2] == FALSE) return FALSE;
		if (i == 3 && eq->joints[3] == FALSE) return FALSE;
		if (i == 4 && eq->joints[4] == FALSE) return FALSE;
	}

	return TRUE;
}

OBJ_DATA * get_materia_char (CHAR_DATA * ch, char * argument)
{
	OBJ_DATA * xObj, * yObj;
	char arg[MIL];
    int number;
    int count;

    number = number_argument (argument, arg);
    count = 0;

	for (xObj = ch->carrying; xObj != NULL; xObj = xObj->next_content)
	{
		if (xObj->item_type == ITEM_MATERIA && is_name (arg, xObj->name))
			if (++count == number)
				return xObj;

		if (xObj->contains != NULL)
		{

			for (yObj = xObj->contains; yObj != NULL;
					yObj = yObj->next_content)
			{
				if (yObj->item_type == ITEM_MATERIA
					&& is_name (arg, yObj->name))
					if (++count == number)
						return yObj;
			}
		}
	}
	return NULL;
}


//Checks for skills in joint materia slots.
bool is_linked_skill (CHAR_DATA * ch, int aSn, int bSn)
{
	OBJ_DATA * eq, * aMat, * bMat;
	int x, y;

	for (eq = ch->carrying; eq != NULL; eq = eq->next_content)
	{
		if ((eq->item_type == ITEM_WEAPON || eq->item_type == ITEM_ARMOR)
			&& eq->wear_loc != WEAR_NONE)
		{
			for (aMat = eq->contains; aMat != NULL; aMat = aMat->next_content)
			{
				for (x = 0; x < 5; x++)
				{
					if (aMat->value[x] == aSn)
					{
						for (bMat = eq->contains; bMat != NULL;
								bMat = bMat->next_content)
						{
							for (y = 0; y < 5; y++)
							{
								if (bMat->value[y] == bSn
									&& is_linked_materia (aMat, bMat))
									return TRUE;
							}
						}
					}
				}
			}
		}
		else continue;
	}
	return FALSE;
}

void do_materia (CHAR_DATA * ch, char *argument)
{
	char arg[MIL], arg2[MIL], arg3[MIL];
	OBJ_DATA * obj, * materia;
	int slot, i;
	bool found = FALSE;

	argument = one_argument (argument, arg);
	argument = one_argument (argument, arg2);
	argument = one_argument (argument, arg3);

	if (arg[0] == '\0')
	{
		send_to_char ("See HELP MATERIA.\n\r", ch);
		return;
	}
	else if (!str_prefix (arg, "set"))
	{
		if (arg2[0] == '\0')
		{
			send_to_char ("Set which Materia?\n\r", ch);
			return;
		}

		if ((materia = get_obj_carry (ch, arg2, ch)) == NULL)
		{
			send_to_char ("You don't have that Materia.\n\r", ch);
			return;
		}

		if (materia->item_type != ITEM_MATERIA)
		{
			send_to_char ("That's not Materia!\n\r", ch);
			return;
		}

		if (arg3[0] == '\0')
		{
			send_to_char ("Set Materia in what item?\n\r", ch);
			return;
		}

		if ((obj = get_obj_carry (ch, arg3, ch)) == NULL
			&& (obj = get_obj_wear (ch, arg3)) == NULL)
		{
			send_to_char ("You don't have anything like that.\n\r", ch);
			return;
		}

		if (obj->item_type != ITEM_WEAPON && obj->item_type != ITEM_ARMOR)
		{
			send_to_char ("You can only set Materia in equipment.\n\r", ch);
			return;
		}

		if (argument[0] != 0 && is_number (argument))
		{
			slot = atoi (argument) - 1;

			if (has_materia_slot (obj, slot))
			{
				send_to_char ("That slot isn't free.\n\r", ch);
				return;
			}
		}
		else
		{
			for (slot = 0; slot < 5; slot++)
			{
				if (!has_materia_slot (obj, slot))
				{
					found = TRUE;
					break;
				}
			}
			if (!found)
			{
				send_to_char ("That object doesn't have a free Materia slot.\n\r", ch);
				return;
			}
		}
	

        obj_from_char (materia);
        obj_to_obj (materia, obj);
		materia->materia_slot = slot;
		send_to_char ("Materia set!\n\r", ch);
		return;
	}
	else if (!str_prefix (arg, "remove"))
	{
		if (arg2[0] == '\0')
		{
			send_to_char ("Remove which Materia?\n\r", ch);
			return;
		}

		if ((materia = get_materia_char (ch, arg2)) == NULL)
		{
			send_to_char ("You don't seem to have that Materia.\n\r", ch);
			return;
		}

		if (materia->item_type != ITEM_MATERIA)
		{
			send_to_char ("That's not Materia!\n\r", ch);
			return;
		}

		if (materia->materia_slot == -1)
		{
			send_to_char ("That Materia isn't set!\n\r", ch);
			return;
		}

        obj_from_obj (materia);
        obj_to_char (materia, ch);
		materia->materia_slot = -1;
		send_to_char ("Materia removed!\n\r", ch);
		return;
	}
	else if (!str_prefix (arg, "check"))
	{
		if (arg2[0] == '\0')
		{
			send_to_char ("Check the Materia of what item?\n\r", ch);
			return;
		}

		if ((obj = get_obj_carry (ch, arg2, ch)) == NULL
			&& (obj = get_obj_wear (ch, arg2)) == NULL)
		{
			send_to_char ("You don't have anything like that.\n\r", ch);
			return;
		}

		printf_to_char (ch, "%s%s%s%s%s%s%s%s%s%s%s\n\r",
				 obj->max_slot >= 1 ? has_materia_slot (obj, 0) ? "(*)" : "( )" : "",
				 obj->joints[0] ? "-" : " ",
				 obj->max_slot >= 2 ? has_materia_slot (obj, 1) ? "(*)" : "( )" : "",
				 obj->joints[1] ? "-" : " ",
				 obj->max_slot >= 3 ? has_materia_slot (obj, 2) ? "(*)" : "( )" : "",
				 obj->joints[2] ? "-" : " ",
				 obj->max_slot >= 4 ? has_materia_slot (obj, 3) ? "(*)" : "( )" : "",
				 obj->joints[3] ? "-" : " ",
				 obj->max_slot >= 5 ? has_materia_slot (obj, 4) ? "(*)" : "( )" : "",
				 obj->joints[4] ? "-" : " ",
				 obj->max_slot >= 6 ? has_materia_slot (obj, 5) ? "(*)" : "( )" : "");
        act ("Materia set in $p:", ch, obj, NULL, TO_CHAR);
		if (obj->contains == NULL)
			send_to_char ("    None.", ch);
		else
		{
			for (materia = obj->contains; materia != NULL;
					materia = materia->next_content)
			{
				printf_to_char (ch, "   (%d) %s{x\n\r",
								materia->materia_slot+1, 
								materia->short_descr);
			}
		}
		return;
	}
	else if (!str_prefix (arg, "stats"))
	{
		if (arg2[0] == '\0')
		{
			send_to_char ("Check the status of what Materia?\n\r", ch);
			return;
		}

		if ((obj = get_materia_char (ch, arg2)) == NULL)
		{
			send_to_char ("You don't have that Materia in your inventory.\n\r", ch);
			return;
		}

		if (obj->item_type != ITEM_MATERIA)
		{
			send_to_char ("That's not Materia!\n\r", ch);
			return;
		}


		printf_to_char (ch, "Materia Name: %s\n\r"
							"AP to Level:  %d\n\r",
							obj->short_descr, 
							obj->level < 5 ? ap_per_level (obj->level)
							- obj->ap : 0);
		if (obj->in_obj != NULL)
			printf_to_char (ch, "Set Into:     %s\n\r",
							obj->in_obj->short_descr);
					

        act ("Abilities contained within $p:", ch, obj, NULL, TO_CHAR);
		for (i = 0; i < 5; i++)
		{
			printf_to_char (ch, "  %s%s",
				obj->value[i] != -1 ? skill_table[obj->value[i]].name : "",
				obj->value[i] != -1 ? "\n\r" : "");
		}
		return;
	}
	else if (!str_prefix (arg, "list"))
	{
		send_to_char ("You posess the following Materia:\n\r", ch);
		for (obj = ch->carrying; obj != NULL; obj = obj->next_content)
		{
			if (obj->item_type == ITEM_MATERIA)
			{
				printf_to_char (ch, "    %25s\n\r", obj->short_descr);
				found = TRUE;
			}
			if (obj->contains != NULL)
			{
				for (materia = obj->contains; materia != NULL;
						materia = materia->next_content)
				{
					found = TRUE;
					if (materia->materia_slot != -1)
						printf_to_char (ch, "    %25s (set in %s)\n\r",
							materia->short_descr, obj->short_descr);
					else
						printf_to_char (ch, "    %25s\n\r",
									materia->short_descr);
				}
			}
		}
		if (!found)
			send_to_char ("    None.", ch);
		return;
	}
	else
	{
		send_to_char ("See HELP MATERIA.\n\r", ch);
		return;
	}
}
