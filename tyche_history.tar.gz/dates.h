/*! \file dates.h
    Date Calculation Routines.
    A collection of date calculation routines that are Year 2000
    compliant for MMDDYYYY or MMDDYY string dates.
 \author Jon A. Lambert
 \version 1.96
 \date 06/27/2002
 \remarks
    This code copyright (C) 2000-2002 by Jon A. Lambert<BR>
    <antilochos@ix.netcom.com> -  All rights reserved.<BR>
    No part of this code may be used without my written consent.<BR>
 This code released to the PUBLIC DOMAIN on 4/2/2006
*/

/* dates.c */
extern long  DaysSince1800(const char * date);
extern int   DaysInMonth(int month, int year);
extern bool  IsLeapYear(int year);
extern int   Month(const char * date);
extern int   Day(const char * date);
extern int   Year(const char * date);
extern void  MakeDateString(char * date, struct tm * dt);
extern bool  ValidateDate(char* dt);
