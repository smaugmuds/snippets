/*! \file history.h
 This module keeps track of and reports historical data including
 logon/logoff statistics, playing time, character creation/deletion,
 and user counts.
 \author Jon A. Lambert
 \version 1.96
 \date 06/27/2002
 \remarks
    This code copyright (C) 2000-2002 by Jon A. Lambert<BR>
    <antilochos@ix.netcom.com> -  All rights reserved.<BR>
    No part of this code may be used without my written consent.<BR>

This code released to the PUBLIC DOMAIN on 4/2/2006
*/

struct stats {
  int max_on;
  int current_juldate;
  char current_date[MAX_INPUT_LENGTH];
  int current_hour;
  int current_weekday;
  int current_play_time;
  int current_logins;
  int current_logouts;
  int current_deletions;
  int current_creates;
};

extern struct stats g_stats;

extern void update_stats ();
