 /*************************************************************************************************** 
  * Well, lets see if I can write better instructions for this snippet								*
  * Than I did for my cmdeditor (Sorry about that, expect a re-releace soon!						*
  *																									*
  *		This would be ShadowStorms Religion code V1.0. I hope people apreciate this					*
  * It took many hours of my life to write, and debug, so have fun with this, and					*
  * feel free to e-mail me with ideas on what you may want in a future releace						*
  * Now, I left a few things out of this from my codebase, because it would require					*
  * an extensive re-work of a few systems to match the way ShadowStorm handles things				*
  * What I left out, was how bless points work, I'm not gunna get into it here, but you				*
  * can remove them, or use them, or whatever, its being left in -your- hands! I will				*
  * be supplying you with the code from my creation function, it wont just slap right				*
  * in, because my creation is quite different from Roms flavour. This snippet really isn't			*
  * for those who dont know the ways around thier codebase, its just basics. It will allow			*
  * you to have people initiated into religions, switch in factions, gain ranks, abilities, etc.	*
  * I hope its all rather simple for you.															*
  *																									*
  *	  Now, what do I want out of you for using this snippet? Apsolutly nothing. Leave credits in if	*
  * You want, I can't really stop you, nor would I waiste my time. Note, I don't have helpfiles for *
  * these commands, if you ever write one, and feel the need to share, send them to me via Email at	*
  * DavionKalhen@hotmail.com and they will be releaced in the next instalment of the religion code	*
  * along with what ever name you supply and the mud URL/Port.										*
  ***************************************************************************************************/				

  /* This code was developed for ShadowStorm at beyond.kyndig.com:5500 with OLC 1.81
											by Davion Kalhen (Aaron Smith-Hayes) */


/*Ok, we'll start by installing the OLC.*/

/*OLC.C*/

	/*To run_olc_editor() add just before the default case.*/
		     case ED_RELIGION:
				rlgedit(d->character, d->incomm);
				break;

	/*To olc_ed_name() add just before default case*/
			  case ED_RELIGION:
                sprintf(buf, "RlgEdit" );
                break;

	/*To show_commands() add to the end of the switch statement*/
			  case ED_RELIGION:
                show_olc_cmds( ch, rlgedit_table );
                break;

	/*Add this structure with the other olc_cmd_types. */
				const struct olc_cmd_type rlgedit_table[] =
				{
					{ "show",               rlgedit_show            },
					{ "name",               rlgedit_name            },
					{ "temple",             rlgedit_temple          },
					{ "faction",            rlgedit_faction         },
					{ "god",                rlgedit_god             },
					{ "donation",           rlgedit_donation        },
					{ "temple",             rlgedit_temple          },
					{ "rank",               rlgedit_rank            },
					{ "skill",              rlgedit_skill           },
					{ "new",                rlgedit_new             },
					{ "list",               rlgedit_list            },
					{ "delete",             rlgedit_delete          },
					{ "command",            show_commands           },
					{ "message",            rlgedit_message         },
					{ NULL,                 0                       }
				};

	/* Add this to the rest of the Interpreters */
			void rlgedit(CHAR_DATA *ch, char *argument )
			{   char religion[MIL];
				char arg[MSL];
				int relg;
				RELIGION *pRelg;

				arg[0] = '\0';

				smash_tilde(argument);
				strcpy(arg, argument);
				argument = one_argument(argument, religion);

				EDIT_RELIGION(ch, pRelg);

				if(!str_cmp(religion, "done") )
				{       edit_done(ch);
						return;
				}
				if(religion[0] == '\0' )
				{       rlgedit_show(ch, argument);
						return;
				}

				for ( relg = 0; rlgedit_table[relg].name != NULL; relg++ )
				{		if ( !str_prefix( religion, rlgedit_table[relg].name ) )
						{		rlgedit_table[relg].olc_fun( ch, argument );
								return;
						}
				}
				interpret(ch, arg);
				return;
			}

	/* Toss this in at the end of the file */

			void do_rlgedit( CHAR_DATA *ch, char *argument )
			{	RELIGION *relg;
		        char arg[MSL];

				if( IS_NPC(ch) )
						return;

				argument = one_argument(argument, arg);

				if( arg[0] == '\0' )
				{       send_to_char("Syntax: Rlgedit <religion>\n\r",ch);
						return;
				}
				if( !str_cmp(arg, "new" ) )
				{       rlgedit_new(ch, argument);
						return;
				}
				if( !str_cmp(arg, "delete" ) )
				{       rlgedit_delete(ch, argument );
						return;
				}
				if( !str_cmp(arg, "list" ) )
				{       rlgedit_list(ch, argument );
						return;
				}
				if( (relg = religion_lookup(arg) )== NULL )
				{       send_to_char("There is no religion by that name.\n\r",ch);
						return;
				}

				ch->desc->pEdit = (void * ) relg;
				ch->desc->editor = ED_RELIGION;
				printf_to_char(ch, "Entering the Religion editor for %s\n\r",relg->name );
				return;
			}

/* END OF OLC.C */

/* OLC.H */
		/*Add this to the connection states. Note: You may not have 13 editors, it may be a lower number */
			#define ED_RELIGION             13

		/*Add to interpeter prototypes */
			void    rlgedit         args( ( CHAR_DATA *ch, char *argument ) );

		/*Add these at the end of the OLC function declarations */
				DECLARE_OLC_FUN( rlgedit_show           );
				DECLARE_OLC_FUN( rlgedit_name           );
				DECLARE_OLC_FUN( rlgedit_temple         );
				DECLARE_OLC_FUN( rlgedit_faction        );
				DECLARE_OLC_FUN( rlgedit_god            );
				DECLARE_OLC_FUN( rlgedit_donation       );
				DECLARE_OLC_FUN( rlgedit_temple         );
				DECLARE_OLC_FUN( rlgedit_rank           );
				DECLARE_OLC_FUN( rlgedit_skill          );
				DECLARE_OLC_FUN( rlgedit_new            );
				DECLARE_OLC_FUN( rlgedit_delete         );
				DECLARE_OLC_FUN( rlgedit_list           );
				DECLARE_OLC_FUN( rlgedit_message        );
		/*Add these to the macro's. */
			#define EDIT_RELIGION( ch, rlg )  ( rlg = (RELIGION *) ch->desc->pEdit )

/*END OF OLC.H */

/*MERC.H */
		/*Add to structure types */
			typedef struct  religion_type       RELIGION;

		/*Add somewhere with the other struct_type definitions */
				#define RANK_INITIATE           0
				#define RANK_ACOLYTE            1
				#define RANK_DISCIPLE           2
				#define RANK_BISHOP                     3
				#define RANK_PRIEST                     4
				#define RANK_DEITY                      5
				#define RANK_GOD                        6
				#define MAX_RELG_RANK                   7

				#define FACTION_ONE                     0
				#define FACTION_TWO                     1
				#define MAX_FACTION                     2

				struct religion_type
				{
						char *          name;
						char *          rank[MAX_CLASS][MAX_RELG_RANK];
						bool            isfaction; // TRUE if faction.
						RELIGION *      main;    // For Factions only.
						char *          deity;   // For Factions only.
						char *          god;    // Main Religion Only.
						RELIGION *      next;
						bool            valid;
						char *          skpell[MAX_CLASS][MAX_RELG_RANK];
						RELIGION *  faction[MAX_FACTION];
						AREA_DATA * temple;
						int                     donation_vnum;
						char *          sac_msg;
						char *          pmt_msg;
						char *          dmt_msg;
						char *          chan_name;
				};

		/* Add this to the pc_data structure */
			    RELIGION    *       religion;
			    sh_int              rank;
			
		/*Add to character Macro's. */

				#define IN_FACTION(ch)                  ( (ch)->pcdata->religion->isfaction )
				#define HAS_RELIGION(ch)                ( (ch)->pcdata->religion )
				#define IS_SAME_RELIGION(ch, vct)       ( (ch)->pcdata->religion == (vct)->pcdata->religion )

		/* Add to Globle Variables */
				extern          RELIGION          *     religion_list;

		/* Add to data file thing NOTE: When doing this, make sure these paths exist (mkdir to make a directory in linux) 
		 * As well, create a religion.lst in the specified path, and just put the '$' character in it*/
			#define RELG_DIR        "../data/religion/"
			#define RELG_LIST       "../data/religion/religion.lst"

		/*Add under the recycle.c prototypes */
			//Religion.c
			void religious_sacrifice args ( (CHAR_DATA *ch, OBJ_DATA *obj ) );
			void save_religion  args ( () );
			void load_religion  args ( () );

/* END OF MERC.H */

/* Right, this is where you need to be able to write code This is for the creation stuff *
 * So I'll give you the general output, and the part that gets the argument. My creation *
 * Is menu based, so It probaby'll look funny :) */

 /*Output*/
                                     send_to_char("\n\r{DThe following Religions are available{r:\n\r", ch);
                                        for ( pRlg = religion_list; pRlg ; pRlg = pRlg->next )
                                        {       printf_to_char(ch, "{D%s {r-{D %s\n\r{x", pRlg->name, pRlg->god );
                                                if(pRlg->faction[FACTION_ONE] )
                                                        printf_to_char(ch, "\t{DFaction{r:{W {D%s {r- {D%s\n\r", pRlg->faction[FACTION_ONE]->name, pRlg->fact$
                                                if(pRlg->faction[FACTION_TWO] )
                                                        printf_to_char(ch, "\t{DFaction{r:{W {D%s {r- {D%s\n\r", pRlg->faction[FACTION_TWO]->name, pRlg->fact$
                                        }
                                        send_to_char("{DNone {r-{D None.\n\r",ch);

                                        write_to_buffer(d,"\n\r",0);
                                        send_to_char( "{DWhere do you place your faith? (help for more information)?\n\rEnter religion{W-> ", ch);

/*Remember you have to add a new CON_ state, or you can leave it to be initiated in game */
/*This is the interpeter for it*/
	one_argument(argument,arg);
	if (!strcmp(arg,"help"))
	{	argument = one_argument(argument,arg);
	    if (argument[0] == '\0')
			do_help(ch,"gods");
	    else
	        do_help(ch,argument);
	    send_to_char("{DWhere do you place your faith? (help for more information)?\n\rEnter religion{W-> {x", ch);
	    break;
	}
    if(!str_cmp(argument, "None" ) )
    {	send_to_char("{DYou have chosen the path of a Heathen. May the gods {rNOT{D be with you.{x\n\r\n\r", ch);
        ch->pcdata->religion = NULL;
        write_to_buffer( d, echo_on_str, 0 );
        //You have to add a d->connected = <where you want them to go> here.
		break;
    }

	if( ( pRlg = religion_lookup(argument) ) == NULL )
    {	if( ( pRlg = faction_lookup(argument ) ) == NULL )
        {	send_to_char("That isn't a valid Religion or Faction.\n\r",ch);
            return;
        }
    }
    printf_to_char(ch, "{DYour faith is placed in {W%s{x.\n\r\n\r", pRlg->name );
    ch->pcdata->religion = pRlg;
    write_to_buffer( d, echo_on_str, 0 );
	// You have to add d->connected = <where you want them to go> here.
    break;

/*Thats it for creation */

/*I added a call to save_religion() in my auto saver, you can add it to the top of do_asave. But make sure to add it somewhere!*/
/*DB.C*/

	/*Add to globles */
		RELIGION  *             religion_list;

	/*add to boot_db() after load_songs*/
		load_religion();

/*END OF DB.C*/

/*SAVE.C*/

	/*Add to fwrite_char, right above the fprintf for passwords */
        if(ch->pcdata->religion )
        {       fprintf(fp, "Rlg %s~\n", ch->pcdata->religion->name );
                fprintf(fp, "Rrnk %d\n", ch->pcdata->rank );
                fprintf(fp, "Blss %d\n", ch->pcdata->bless ); // If you chose not to use blesspoints, remove this
        }

	/*Add to load_char_obj somewhere */
        ch->pcdata->religion = NULL;
        ch->pcdata->bless = 0;
        ch->pcdata->rank = 0;

	/*Add to Fread_char under case 'B' NOTE: if you didn't use bless points, ignore */
		KEY( "Blss", ch->pcdata->bless,         fread_number( fp ) );

	/*Add to fread_char under case 'R' */
	                    if( !str_cmp( word, "Rlg" ) )
                        {       char *string;
                                free_string(string);
                                string = fread_string(fp);
                                if( (ch->pcdata->religion = religion_lookup(string ) ) == NULL )
                                        if( ( ch->pcdata->religion = faction_lookup(string) ) == NULL )
                                                logf2("BUG: Player found with invalid religion! %s", string );
                                fMatch = TRUE;
                                break;
                        }
                        KEY( "Rrnk",     ch->pcdata->rank,              fread_number( fp ) );
/*END OF SAVE.C */

/*Right. I think thats it. Make sure that religion.lst exists and has the '$' as the only thing in the file */
/*Then copyover, add the do_functions to interp.h/c


