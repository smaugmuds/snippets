Files included in this zip:
Merc22.patch - Fixes compiler warnings and errors in stock Merc 2.2 Sands. Install first.
Merc22MCCPMXP.patch - Adds MCCP1 and full MXP 1.0 functionality to Stock Merc 2.2 Sands.

Just a few notes on mccp... You can get MCCP information at http://www.zuggsoft.com/zmud/mcp.htm. For those of you with copyover/hotreboot functions in your mud do not forget to put compressEnd2(); somewhere before it saves that descriptor for the copyover, I usually put it after the following at the begining of do_hotreboot. Also you do not need to reinitialize mccp after the copyover it will do that automatically. Also note that write_to_descriptor was renamed to write_to_descriptor_2 which should only need to be called during hotreboot functions in mccp.c and mxp.c. write_to_descriptor now points to d not d->descriptor so you want to use write_to_descriptor( d, buf, 0 ); not write_to_descriptor( d, buf, 0 );

        for (d = first_desc; d ; d = d_next)
        {
                CHAR_DATA * och = CH (d);
                compressEnd2(d);

some notes on mxp... You want to use mxp_to_char instead of send_to_char to send MXP tags to your players. you can get MXP tag Information from http://www.zuggsoft.com/zmud/mxp.htm. Please note that the tags Version and Support are supported by the MXP parser but I have not yet written up a parser to parse out the information sent back to the MUD from the client. Just one side note, I had a problem with MXp not parsing out tags in multi-line situations like room descriptions, something about the parser not liking /n/r I may or may not have fixed this by using dystopias write_to_descriptor, I haev not had a chance to test this yet.

Thanks to Brian Graversen for writing his mxp.c and mxp.h so that I could expand upon them full MXP functionality and make this patch for Merc 2.2
and Thanks to Oliver Jowett for writing his mccp.c, I tried to use Brian Graversens patch for godwars mccp to do this and got frustrated because it did not work, it would not detect mccp2 only mccp1 and once you disabled it you couldnt reenable it. I ripped this mccp.c from dystopia.

If you have any problems adding this to your mud feel free to email me, or contact me on yahoo or aol with the screenname Celestian1.

-Celestian (celestian1@gmail.com)